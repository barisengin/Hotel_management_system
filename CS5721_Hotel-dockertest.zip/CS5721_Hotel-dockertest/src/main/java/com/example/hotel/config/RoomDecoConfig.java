package com.example.hotel.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.hotel.service.impl.decorator.CachingRoomInfoServiceDecorator;
import com.example.hotel.service.impl.decorator.LoggingRoomInfoServiceDecorator;
import com.example.hotel.service.impl.room.RoomInfoServiceImpl;
import com.example.hotel.service.room.RoomInfoService;

@Configuration
public class RoomDecoConfig {
    @Bean
    public RoomInfoService roomInfoService(RoomInfoServiceImpl roomInfoServiceImpl) {
        // Wrap the original service with decorators
        RoomInfoService loggingDecorator = new LoggingRoomInfoServiceDecorator(roomInfoServiceImpl);
        return new CachingRoomInfoServiceDecorator(loggingDecorator);
    }
}
